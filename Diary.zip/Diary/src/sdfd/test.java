package sdfd;

public class test {
	public static void main(String[] args) {
		ShowDiary SD = new ShowDiary();
	}
}
